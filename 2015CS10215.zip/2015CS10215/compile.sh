#!/bin/bash
g++ -std=c++11 Clustering_Algorithms_Implementation/kmeans/working_k_means.cpp -o kmeans
g++ -std=c++11 Clustering_Algorithms_Implementation/dbscan/dbscan.cpp Clustering_Algorithms_Implementation/dbscan/kdtree.cpp -o dbscan
g++ -std=c++11 Clustering_Algorithms_Implementation/optics/optics.cpp -o optics