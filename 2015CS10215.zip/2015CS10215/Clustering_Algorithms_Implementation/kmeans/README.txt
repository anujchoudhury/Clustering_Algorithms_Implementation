to run code
g++ working_k_means.cpp
a <num_clusters> <file_name>