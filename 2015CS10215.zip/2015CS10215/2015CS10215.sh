#!/bin/bash
if [ $1 = "-kmeans" ]
then
	./kmeans $2 $3  
elif [ $1 = "-dbscan" ]
then
	./dbscan $3 $2 $4 >"dbscan.txt"
elif [ $1 = "-optics" ]
then
	./optics $3 $2 $4
	python Clustering_Algorithms_Implementation/optics/plotter.py
fi