
import pickle
import math
import numpy as np
# from svmutil import *
from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score


train_file = 'aido99_allre.txt.fp'

freq_subs = open(train_file,'r')
log_ratio = {}
g_ratio = {}
pos_set = {}
neg_set = {}

f = open("picklestore", "rb")
indemapper = pickle.load(f)
relindex = pickle.load(f)
trainsize=pickle.load(f)
testsize=pickle.load(f)
f.close()
len_total = (trainsize)

fl = False
curr_id = -1
for line in freq_subs:
	if line[0] == 't':
		data = line.split(' ')
		curr_id = int(data[2])
		pos_set[curr_id]=set()
		neg_set[curr_id]=set()
		#print(curr_id)
	elif line[0]=='x':
		data = line.split(' ')[1:]
		p = 0
		n = 0
		for grph in data:
			if grph == '\n':
				continue
			if relindex[indemapper[int(grph)]]==1:
				p+=1
				pos_set[curr_id].add(int(grph))
			elif relindex[indemapper[int(grph)]]==-1:
				n+=1
				neg_set[curr_id].add(int(grph))
		p_freq = float(p)/float(len_total)
		n+=1
		n_freq = float(n)/float(len_total)
		if p_freq != 0 and len(data) < len_total/2:
			g_ratio[curr_id]=p_freq*(math.log(float(p_freq)/float(n_freq))) + (1-p_freq)*(math.log((1.0-float(p_freq))/(1.0-float(n_freq))))


act = [k for (k, v) in relindex.items() if v==-1]
num_of_features = min(1000,len(g_ratio))
sorted_names = sorted([(value,key) for key, value in g_ratio.items()],
                  reverse=True)[:num_of_features]

theta = 0.05

label = {}
for item in sorted_names:
	label[item[1]] = 1

for item1 in sorted_names:	
	if label[item1[1]]==0:
		continue
	for item2 in sorted_names:
		if item1[1]==item2[1] or label[item2[1]]==0:
			continue
		p_set1 = pos_set[item1[1]]
		p_set2 = pos_set[item2[1]]
		n_set1 = neg_set[item1[1]]
		n_set2 = neg_set[item2[1]]
		pos_freq = max(len(p_set1-p_set2),len(p_set2-p_set1))
		neg_freq = max(len(n_set1-n_set2),len(n_set2-n_set1))		

		p = pos_freq/(len(p_set1)+len(p_set2))
		n = neg_freq/(len(n_set1)+len(n_set2))

		if p < theta and n < theta:
			label[item2[1]] = 0

disc_freq_set = {}
i=0
outfile = open('frequent_id.txt','w')
for item in sorted_names:
	if label[item[1]] == 0:
		continue
	disc_freq_set[item[1]]=i
	outfile.write(str(item[1]) + "\n")
	i+=1
outfile.close()

# print(sorted_names)


output_label = [0]*trainsize
input_data = [0]*trainsize
test_data = [0]*testsize
for i in range(trainsize):
    input_data[i] = [0]*num_of_features

for i in range(testsize):
    test_data[i] = [0]*num_of_features



for i in range(0,len_total):
	val = relindex[indemapper[i]]
	if val == 1:
		output_label[i] = 1
	elif val == -1:
		output_label[i] = 0

freq_subs.seek(0,0)

fl = False
curr_id = -1
for line in freq_subs:
	if fl == True and line[0]!='t':
		continue
	if line[0] == 't':
		data = line.split(' ')
		if int(data[2]) in disc_freq_set:
			curr_id = int(data[2])
			fl = False
		else:
			fl = True
	elif line[0]=='x':
		data = line.split(' ')[1:]
		for grph in data:
			if grph == '\n':
				continue
			if(int(grph)<trainsize):
				input_data[int(grph)][disc_freq_set[curr_id]]=1
			else:
				test_data[int(grph)-trainsize][disc_freq_set[curr_id]]=1

f1=open("traintest",'wb')
pickle.dump(input_data,f1)
pickle.dump(output_label,f1)
pickle.dump(test_data,f1)
f1.close()
print(len(disc_freq_set))
ftrain=open("train.txt",'w')
for i in range(len(input_data)):
	ftrain.write(str(output_label[i])+" ")
	for j in range(len(input_data[i])):
		ftrain.write(str(j)+":"+str(input_data[i][j])+" ")
	ftrain.write("\n")
ftrain.close()

ftest=open("test.txt",'w')
for i in range(len(test_data)):
	for j in range(len(test_data[i])):
		ftest.write(str(j)+":"+str(test_data[i][j])+" ")
	ftest.write("\n")
ftest.close()
