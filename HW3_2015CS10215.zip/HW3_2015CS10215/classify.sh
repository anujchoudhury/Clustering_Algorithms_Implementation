#!/bin/bash
python3 finalrealconverter.py $1 $2 $3 $4
./gSpan6/gSpan -f aido99_allre.txt -s 0.04 -o -i
python3 discriminative_featuer_extraction.py