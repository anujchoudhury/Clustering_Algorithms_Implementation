# ca.txt ci.txt aido99_all.txt aido99_allre.txt testdata.txt picklestore vertexmap
# outputs aido99_allre.txt picklestore vertexmap
# fs5.txt for better
import sys
fpos=open(sys.argv[2],'r')
fneg=open(sys.argv[3],'r')
relindex={}
# neg_ind={}

apos=fpos.readline()
while(apos!=''):
	curint=int(apos)
	relindex[curint]=1
	apos=fpos.readline()

aneg=fneg.readline()
while(aneg!=''):
	curint=int(aneg)
	relindex[curint]=-1
	aneg=fneg.readline()

fpos.close()
fneg.close()

f=open(sys.argv[1],'r')
fo=open('aido99_allre.txt','w')

# fn=open('filenums.txt','w')

indexmapper={}
mapvert={}
indexvert=0
mapedge={}
indexedge=0
startind=0
a11=f.readline()
while(a11!=''):
	graphnum=int(a11[1:])
	# fn.write(a11)
	if(graphnum in relindex):
		indexmapper[startind]=graphnum
	else:
		indexmapper[startind]=graphnum
		relindex[graphnum]=-1
	fo.write('t # '+str(startind)+'\n')
	startind+=1
	numvertex=int(f.readline())
	for i in range(numvertex):
		labelvert=f.readline()
		reallabel=(labelvert.split())[0]
		if(reallabel not in mapvert):
			mapvert[reallabel]=indexvert
			indexvert+=1
		fo.write('v '+str(i)+' '+str(mapvert[reallabel])+'\n')
	numedge=int(f.readline())
	for i in range(numedge):
		labeledge=f.readline()
		listedge=labeledge.split()
		edgelabel=listedge[2]
		if(edgelabel not in mapedge):
			mapedge[edgelabel]=indexedge
			indexedge+=1
		labeledgeprint=str(listedge[0])+' '+str(listedge[1])+' '+str(listedge[2])+'\n'
		fo.write('e '+str(labeledgeprint))
	a11=f.readline()
# fo.write('t # -1\n')
f.close()

#print startind to find train data size
# print(startind)
trainsize = startind
ft=open(sys.argv[4],'r')
a11=ft.readline()
while(a11!=''):
	graphnum=int(a11[1:])
	# fn.write(a11)
	relindex[graphnum]=0
	indexmapper[startind]=graphnum
	fo.write('t # '+str(startind)+'\n')
	startind+=1
	numvertex=int(ft.readline())
	for i in range(numvertex):
		labelvert=ft.readline()
		reallabel=(labelvert.split())[0]
		if(reallabel not in mapvert):
			mapvert[reallabel]=indexvert
			indexvert+=1
		fo.write('v '+str(i)+' '+str(mapvert[reallabel])+'\n')
	numedge=int(ft.readline())
	for i in range(numedge):
		labeledge=ft.readline()
		listedge=labeledge.split()
		edgelabel=listedge[2]
		if(edgelabel not in mapedge):
			mapedge[edgelabel]=indexedge
			indexedge+=1
		labeledgeprint=str(listedge[0])+' '+str(listedge[1])+' '+str(listedge[2])+'\n'
		fo.write('e '+str(labeledgeprint))
	a11=ft.readline()
# fo.write('t # -1\n')
testsize = startind - trainsize
fo.close()
ft.close()
print(startind)
#startind-oldstartind=test data size

import pickle

# write a file
f = open("picklestore", "wb")
pickle.dump(indexmapper, f)
pickle.dump(relindex, f)
pickle.dump(trainsize,f)
pickle.dump(testsize,f)
f.close()

# f = open("picklestore", "rb")
# indemapper = pickle.load(f)
# relindex = pickle.load(f)
# f.close()

f = open("vertexmap", "w")
for key in mapvert:
	f.write(str(key)+" "+str(mapvert[key])+"\n")
# pickle.dump(mapvert, f)
# f.write("\n")
f.write("@ "+str(indexvert)+"\n")
# pickle.dump(indexvert, f)
f.close()



# f = open("picklestore", "rb")
# indemapper = pickle.load(f)
# relindex = pickle.load(f)
# f.close()

# f = open("vertexmap", "wb")
# mapvert = pickle.load( f)
# indexvert = pickle.load( f)
# f.close()
